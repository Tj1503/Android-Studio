package com.example.studyplanner;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Lecture extends Fragment {

    private SqliteDatabase mDatabase;
    View view;
    RecyclerView eventView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_lecture, container, false);
        eventView = (RecyclerView) view.findViewById(R.id.myEventList);
        eventView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        eventView.setHasFixedSize(true);

       /* super.onCreate(savedInstanceState);
        setC(R.layout.activity_main);
        RecyclerView contactView = findViewById(R.id.myEventList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        contactView.setLayoutManager(linearLayoutManager);
        contactView.setHasFixedSize(true);*/
        mDatabase = new SqliteDatabase(getContext());
        ArrayList<Eventclass> allEvents = mDatabase.listEventsOfType("Lecture");
        if (allEvents.size() > 0) {
            eventView.setVisibility(View.VISIBLE);
            EventAdapter mAdapter = new EventAdapter(getContext(), allEvents);
            eventView.setAdapter(mAdapter);
        }
        else {
            eventView.setVisibility(View.GONE);
            Toast.makeText(getContext(), "There are no events in the database. Start adding now", Toast.LENGTH_LONG).show();
        }
        Button btnAdd = (Button) view.findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addTaskDialog();
            }
        });
        return view;
    }
    private void addTaskDialog() {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View subView = inflater.inflate(R.layout.add_events, null);

        final EditText titleField = subView.findViewById(R.id.enterTitle);
        final EditText dateField = subView.findViewById(R.id.enterDate);
        final EditText timeField = subView.findViewById(R.id.enterTime);
        final EditText descField = subView.findViewById(R.id.enterDesc);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add new Event");
        builder.setView(subView);
        builder.create();
        builder.setPositiveButton("ADD EVENT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                final String title = titleField.getText().toString();
                final String time = timeField.getText().toString();
                final String desc = descField.getText().toString();
                final String date = dateField.getText().toString();

                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(getContext(), "Something went wrong. Check your input values", Toast.LENGTH_LONG).show();
                }
                else {
                    Eventclass newEvent = new Eventclass("Lecture",title,date,time,desc);
                    mDatabase.addEvents(newEvent);
                  /*  Intent intent=new Intent(getActivity(),StudyPlan.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                    startActivity(intent);*/
                }
            }
        });
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.setReorderingAllowed(false);
        ft.detach(this).attach(this).commit();
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext(), "Task cancelled", Toast.LENGTH_LONG).show();
            }
        });
        builder.show();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mDatabase != null) {
            mDatabase.close();
        }
    }
}
