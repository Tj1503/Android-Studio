package com.example.studyplanner;

import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

class EventViewHolder extends RecyclerView.ViewHolder {
    TextView tvTitle, tvType,tvDate,tvTime,tvDesc;
    ImageView deleteEvent;
    ImageView editEvent;
    EventViewHolder(View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.eventTitle);
        tvType = itemView.findViewById(R.id.eventType);
        tvDate = itemView.findViewById(R.id.eventDate);
        tvTime=itemView.findViewById(R.id.eventTime);
        tvDesc=itemView.findViewById(R.id.eventDesc);

        deleteEvent = itemView.findViewById(R.id.deleteEvent);
        editEvent = itemView.findViewById(R.id.editEvent);
    }
}
