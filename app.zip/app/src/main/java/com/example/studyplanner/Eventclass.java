package com.example.studyplanner;

public class Eventclass {
    private int id;
    private String title;
    private String type;
    private String date;
    private String time;
    private String description;


    Eventclass(String type, String title,String date,String time,String description) {
        this.title = title;
        this.time = time;
        this.date =date;
        this.type = type;
        this.description = description;

    }

    Eventclass(int id,String type, String title,String date,String time,String description) {
        this.id=id;
        this.title = title;
        this.time = time;
        this.date =date;
        this.type = type;
        this.description = description;

    }
    int getId() {
        return id;
    }
    public String getType() {
        return type;
    }
    public String getTitle() {
        return title;
    }
    public String getDate() {
        return date;
    }
    public String getTime() {
        return time;
    }
    public String getDescription() {
        return description;
    }


    public void setId(int id) {
        this.id = id;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public void setType(String type) {
        this.type = type;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}
