package com.example.studyplanner.ui.calendar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.studyplanner.Eventclass;
import com.example.studyplanner.R;
import com.example.studyplanner.SqliteDatabase;
import java.util.ArrayList;
import java.util.Date;

public class CalendarFragment extends Fragment {

    CalendarView calendar;
    TextView row1,row2,row3,row4;
    private SqliteDatabase mDatabase;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_calendar,container, false);

        calendar=(CalendarView) view.findViewById(R.id.calendarView);
        row1=(TextView) view.findViewById(R.id.noOfLectures);
        row2=(TextView) view.findViewById(R.id.noOfStudyPlan);
        row3=(TextView) view.findViewById(R.id.noOfAssignment);
        row4=(TextView) view.findViewById(R.id.noOfExam);

        mDatabase = new SqliteDatabase(getContext());
        ArrayList<Eventclass> allStudyPlanEvents = mDatabase.listEventsOfType("StudyPlan");
        ArrayList<Eventclass> allAssignmentEvents = mDatabase.listEventsOfType("Assignment");
        ArrayList<Eventclass> allLectureEvents = mDatabase.listEventsOfType("Lecture");
        ArrayList<Eventclass> allExamEvents = mDatabase.listEventsOfType("Exam");
        ArrayList<String> allDates = mDatabase.AllDates();

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date;

                if(month+1>9&&dayOfMonth>9) {
                    date = dayOfMonth + "-" + (month + 1) + "-" + year;
                }
                else if(month+1<10&&dayOfMonth<10){date = "0" + dayOfMonth + "-0" + (month + 1) + "-" + year;}
                else if(month+1<10){date = dayOfMonth + "-0" + (month + 1) + "-" + year;}
                else {date = "0" + dayOfMonth + "-" + (month + 1) + "-" + year;}
                int studyplan=0;
                int assignments=0,lectures=0,exam=0;
                //row1.setText(date);
                for(Eventclass events : allStudyPlanEvents){
                    if(events.getDate().equals(date)){
                        studyplan+=1;
                    }
                }
                for(Eventclass events : allAssignmentEvents){
                    if(events.getDate().equals(date)){
                        assignments+=1;
                    }
                }
                for(Eventclass events : allLectureEvents){
                    if(events.getDate().equals(date)){
                        lectures+=1;
                    }
                }
                for(Eventclass events : allExamEvents){
                    if(events.getDate().equals(date)){
                        exam+=1;
                    }
                }
                for(String sdate : allDates){
                    String[] datesList= sdate.split("-");
                    int day=Integer.parseInt(datesList[0]);
                    int monthdate=Integer.parseInt(datesList[1]);
                    int yeardate=Integer.parseInt(datesList[2]);
                }
                row1.setText(String.valueOf(lectures));
                row2.setText(String.valueOf(studyplan));
                row3.setText(String.valueOf(assignments));
                row4.setText(String.valueOf(exam));



            }
        });


        return view;

    }



}
