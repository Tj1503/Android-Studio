package com.example.studyplanner;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Objects;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
class EventAdapter extends RecyclerView.Adapter<EventViewHolder> implements Filterable {
    private Context context;
    private ArrayList<Eventclass> listEvents;
    private ArrayList<Eventclass> mArrayList;
    private SqliteDatabase mDatabase;
    EventAdapter(Context context, ArrayList<Eventclass> listEvents) {
        this.context = context;
        this.listEvents = listEvents;
        this.mArrayList = listEvents;
        mDatabase = new SqliteDatabase(context);
    }
    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_list_layout, parent, false);
        return new EventViewHolder(view);
    }
    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        final Eventclass events = listEvents.get(position);
        holder.tvTitle.setText(events.getTitle());
        holder.tvDate.setText(events.getDate());
        holder.tvType.setText(events.getType());
        holder.tvTime.setText(events.getTime());
        holder.tvDesc.setText(events.getDescription());

        holder.editEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTaskDialog(events);
            }
        });
        holder.deleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabase.deleteEvent(events.getId());
                ((Activity) context).finish();
                context.startActivity(((Activity) context).getIntent());
            }
        });
    }
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    listEvents = mArrayList;
                }
                else {
                    ArrayList<Eventclass> filteredList = new ArrayList<>();
                    for (Eventclass events : mArrayList) {
                        if (events.getTitle().toLowerCase().contains(charString)) {
                            filteredList.add(events);
                        }
                    }
                    listEvents = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = listEvents;
                return filterResults;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                listEvents = (ArrayList<Eventclass>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
    @Override
    public int getItemCount() {
        return listEvents.size();
    }
    private void editTaskDialog(final Eventclass events) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View subView = inflater.inflate(R.layout.add_events, null);
        final EditText titleField = subView.findViewById(R.id.enterTitle);
        final EditText typeField = subView.findViewById(R.id.enterType);
        final EditText dateField = subView.findViewById(R.id.enterDate);
        final EditText timeField = subView.findViewById(R.id.enterTime);
        final EditText descField = subView.findViewById(R.id.enterDesc);

        if (events != null) {
            titleField.setText(events.getTitle());
            dateField.setText(String.valueOf(events.getDate()));
            typeField.setText(events.getType());
            timeField.setText(events.getTime());
            descField.setText(events.getDescription());
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit event");
        builder.setView(subView);
        builder.create();
        builder.setPositiveButton("EDIT EVENT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String title = titleField.getText().toString();
                final String time = timeField.getText().toString();
                final String type = typeField.getText().toString();
                final String desc = descField.getText().toString();
                final String date = dateField.getText().toString();

                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(context, "Something went wrong. Check your input values", Toast.LENGTH_LONG).show();
                } else {
                    mDatabase.updateEvents(new
                            Eventclass(Objects.requireNonNull(events).getId(), type,title,date,time,desc));
                    ((Activity) context).finish();
                    context.startActivity(((Activity)
                            context).getIntent());
                }
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context, "Task cancelled",Toast.LENGTH_LONG).show();
            }
        });
        builder.show();
    }
}
