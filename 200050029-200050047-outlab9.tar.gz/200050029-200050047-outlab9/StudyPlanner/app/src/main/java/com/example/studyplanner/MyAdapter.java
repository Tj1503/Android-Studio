package com.example.studyplanner;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MyAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;

    public MyAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }

    // this is for fragment tabs
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                StudyPlan studyPlan = new StudyPlan();
                return studyPlan;
            case 1:
                Assignment assignment = new Assignment();
                return assignment ;
            case 2:
                Exam exam = new Exam();
                return exam;
            case 3:
                Lecture lecture = new Lecture();
                return lecture;
            default:
                return null;
        }
    }

    // this counts total number of tabs
    @Override
    public int getCount() {
        return totalTabs;
    }
}