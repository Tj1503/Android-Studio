package com.example.studyplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
public class SqliteDatabase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 5;
    private static final String DATABASE_NAME = "db";
    private static final String TABLE_EVENTS = "events";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TYPE = "type";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_DESC = "description";

    public SqliteDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_EVENTS_TABLE = "CREATE TABLE "
                + TABLE_EVENTS + "(" + COLUMN_ID
                + " INTEGER PRIMARY KEY,"
                + COLUMN_TYPE + " TEXT,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_DATE + " TEXT,"
                + COLUMN_TIME + " TEXT,"
                + COLUMN_DESC + " TEXT"
                +")";
        db.execSQL(CREATE_EVENTS_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }
    public ArrayList<Eventclass> listEventsOfType(String eventType) {
        String sql = "select * from " + TABLE_EVENTS + " where " + COLUMN_TYPE + " = '"+eventType+"'";

        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Eventclass> storeEvents = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                int id = Integer.parseInt(cursor.getString(0));
                String type = cursor.getString(1);
                String title = cursor.getString(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                String desc = cursor.getString(5);
                storeEvents.add(new Eventclass(id, type,title, date, time,desc));
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return storeEvents;
    }
    void addEvents(Eventclass event) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, event.getType());
        values.put(COLUMN_TITLE, event.getTitle());
        values.put(COLUMN_DATE, event.getDate());
        values.put(COLUMN_TIME, event.getTime());
        values.put(COLUMN_DESC, event.getDescription());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_EVENTS, null, values);
    }
    void updateEvents(Eventclass event ) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, event.getType());
        values.put(COLUMN_TITLE, event.getTitle());
        values.put(COLUMN_DATE, event.getDate());
        values.put(COLUMN_TIME, event.getTime());
        values.put(COLUMN_DESC, event.getDescription());
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(TABLE_EVENTS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(event.getId())});
    }
    void deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }
    public ArrayList<String> AllDates(){
        String sql = "select * from " + TABLE_EVENTS + "";
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<String> storeDates = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                String date = cursor.getString(3);
                storeDates.add(date);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return storeDates;
    }
}